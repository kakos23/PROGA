import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class ServerThread extends Thread {
	Socket client;
	String session;
	Date lastAction;
	OutputStreamWriter writer;
	BufferedReader reader;
	List<String> log;

	ServerThread(Socket socket, Date time) throws IOException {
		client = socket;
		lastAction = time;
		session = Long.toString(lastAction.getTime());
		writer = new OutputStreamWriter(client.getOutputStream());
		reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
		log = new LinkedList<>();
	}

	public void run() {
		try {
			System.out.println("\r\nAccepted\r\nSession:" + session);
			writer.write("Write your example like:5 + 5\r\n");
			writer.flush();

			String request;
			do {
				request = reader.readLine();
				this.updateLastAction();
				log.add(request);
				if (request.equals("get_logs")) {
					int i = 1;
					writer.write("\r\nLogs:");
					writer.flush();
					for (String log_str : log)
					{
						writer.write("\r\n" + i++ + ". " + log_str);
						writer.flush();
					}
					writer.write("\r\nEnd!\r\n");
					writer.flush();
				}
				else {
					writer.write(new Calculator().Calc(request) + "\r\n");
					writer.flush();
				}
			} while (!request.equals("exit"));

			writer.close();
			reader.close();
			client.close();
		} catch (Exception e) {
			System.out.println("Fail thread:" + e.getMessage());
		}

	}

	public void bb() {
		try {
			writer.write("\r\nYou were inactive for 1 minute, bye bye :C");
			writer.flush();
			writer.close();
			reader.close();
			client.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Fail:" + e.getMessage());
		}
	}

	public void updateLastAction() {
		lastAction = new Date();
	}
}
